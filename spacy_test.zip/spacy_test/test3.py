# -*- coding: utf-8 -*-
"""
Created on Mon Feb 11 14:58:58 2019

@author: palak.kala
"""
"""
import configparser
config = configparser.ConfigParser()

config['Annotation']={'File_Location':'C:\\Users\\palak.kala\\Documents\\project\\emailworkbench\\testing',
                       'Filename':'ner_training_data.csv','output_dir':'C:\\Users\\palak.kala\\Documents\\project\\emailworkbench\\testing'}


with open('annotation.ini', 'w') as configfile:
    config.write(configfile)
"""

import pandas as pd 
import configparser
from Function_NER_entities import named_entity
from NER_Invoices import *
from flask import Flask,render_template,request

app=Flask(__name__)
## Reading the ini file 

config = configparser.ConfigParser()


config.read('annotation.ini')

config.sections()

file_location=config['Annotation']['File_Location']
filename=config['Annotation']['Filename']

output_dir=config['Annotation']['output_dir']

data=pd.read_csv(file_location+'\\'+filename)

# converts to annotation 

res=named_entity(data)


@app.route("/", methods=['GET', 'POST'])
def index():
    print(request.method)
    if request.method == 'POST':
        if request.form.get('Ner_Train') == 'Ner_Train':
                # pass
            NerInvoice(res,output_dir)

            return render_template("spacy.html",msg="Please check the output directory to check the train file" )
    
    elif request.method == 'GET':
        # return render_template("index.html")
        print("No Post Back Call")
    return render_template("spacy.html")
    
if __name__=="__main__":
    app.run(debug=True)
