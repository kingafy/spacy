# -*- coding: utf-8 -*-
"""
Created on Mon Feb 11 14:43:38 2019

@author: palak.kala
"""

import pandas as pd 

data1 = pd.read_csv("ner_training_data.csv")

def named_entity(data):
    ls1 = []
    count = data["Entities_Count"]
    for i in range(0,len(count)):
        d1 = data["Text"][i]
        ls = []
        if count[i].astype(str) != 'nan':
            for j in range(0,int(count[i])):
                l2 = (data.iloc[i,2+3*j],data.iloc[i,3+3*j],data.iloc[i,4+3*j])
                ls.append(l2)
        else:
            ls.append([])

        l4 = {"entities" : ls}
        tup2 = (d1, l4)
        ls1.append(tup2)
     
    res_final = pd.DataFrame(ls1)
    res_final.columns = ["Text", "Entities"]
    
    return(res_final)
    
    
#res  = named_entity(data1)


"""
res_final = pd.DataFrame(res)
res_final.columns = ["Text", "Entities"]
res_final

"""